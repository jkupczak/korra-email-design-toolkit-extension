
///////////////////////////////////////
///////////////////////////////////////
///////////////////////////////////////
/////
/////
/////    Updated Relative Resources
/////
/////    Uses URI.js
/////
/////    This does not replace JUST image sources.
/////    It will check and potentially modify every instance of src= in the code.
/////    This includes plain text instances.
/////
///////////////////////////////////////
///////////////////////////////////////
///////////////////////////////////////

var updateRelativeResources = function(code) {

  // variables
  var split, uri, relUri, regex, mark;

  // URI.js needs the filepath to end in a / to properly convert relative URIs to absolute ones
  var fp = filePath + "/";
  fp = fp.replace(/ /g, "%20");


  ////////////////////////////////
  ////////////////////////////////
  var modify = function(match, mark) {

    console.log(match);
    console.log(mark);

    // variables
    var markStart, markEnd;

    // separate the URL from the src=
    if ( mark === '"' || mark === "'" ) {

      markStart = mark;
      markEnd = mark;

      split = match.split(mark);
      console.warn(split);
      uri = new URI(split[1]);
    }
    // Dealing with src= that does not use " or ' is more complicated.
    // We need to clean up any whitespace and account for a closing > character.
    // Then when we create the
    else {
      markStart = "";
      markEnd = ">";
      uri = new URI( match.replace(/(src\s*?=\s*?|\>\s*$)/gi, "").trim() );
      console.log("new uri", uri._parts.path);
    }




    if ( !uri._parts.protocol && !uri._parts.hostname ) {
      relUri = uri.absoluteTo(fp)._string;
      console.warn(relUri);

      regex = new RegExp(match, "gi");
      relUri = 'src=' + markStart + 'file://' + relUri + markEnd;

      console.log(regex);
      console.log(relUri);

      code = code.replace(regex, relUri);
    }
    else {
      console.warn("no edits needed");
    }
  };

  // Find all instances of src="" in the code and loop through them
  // Check for src="" with double quotes, src='' with single quotes, and with src= no quotes
  // No quotes needs to stop when a space is found
  var matches = code.match(/(\s|"|')(src\s*?=\s*?"(.+?)?"|src\s*?=\s*?'(.+?)?'|src\s*?=\s*?([^"'\s]+?)(\s|\>))/gi);
  matches.forEach(function (match, index) {

    // Find the marker we need to use
    if ( /src\s*?=\s*?"/i.test(match) ) {
      console.log('found double-quotes "');
      modify(match, '"');
    }
    else if ( /src\s*?=\s*?'/i.test(match) ) {
      console.log('found single-quotes \'');
      modify(match, "'");
    }
    else if ( /src\s*?=\s*?[^"'\>]/i.test(match) ) {
      console.log('found closing >');
      modify(match, ">");
    }
    else if ( /src\s*?=\s*?[^"'\s]/i.test(match) ) {
      console.log('found space');
      modify(match, " ");
    }

  });

  console.log(code);
  return code;


};
