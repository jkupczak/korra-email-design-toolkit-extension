console.log("...");
console.log( chrome.extension.getURL('preview.html?file=' + document.URL) );
// window.location = chrome.extension.getURL('preview.html?file=') + document.URL;
// window.location = "https://www.google.com";
console.log("...");

// file:///Users/jameskupczak/Desktop/asd.html
